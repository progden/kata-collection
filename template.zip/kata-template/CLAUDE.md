# Kata Module Name

<!-- TODO: 修改為您的 Kata 名稱和描述 -->
Kata 模組描述 - TDD 練習。

## 模組指令

```bash
# 在此目錄執行
../mvnw test

# 或從根目錄執行
./mvnw test -pl module-name

# 執行特定測試
../mvnw test -Dtest="io.progden.katamodule.SomeTest"
```

## 架構

<!-- TODO: 描述主要類別和職責 -->
- `MainClass` - 主要業務邏輯

## 規則摘要

<!-- TODO: 簡要描述 Kata 的規則 -->

## 相關文件

- `../tdd-guide.md` - TDD 測案設計原則
