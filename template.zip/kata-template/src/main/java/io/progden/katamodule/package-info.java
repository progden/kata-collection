/**
 * Kata 模組主要套件。
 * <p>
 * TODO: 修改套件名稱以符合您的模組
 */
package io.progden.katamodule;
