# Kata Module Name

<!-- TODO: 在此貼上 Kata 的題目描述 -->
<!-- 可以參考 https://kata-log.rocks/ 取得各種 Kata 題目 -->

## 題目描述

請在此處填寫 Kata 的完整題目描述。

## 範例

請在此處提供範例輸入和預期輸出。

## 進階挑戰

如果有進階挑戰，請在此處描述。
